# All Remaining TODOs — ArtisanPro

## 0. Before continuing development

Temporary files were cleaned. Install dependencies again when needed:

```bash
npm install
cd artisanpro-admin && npm install
```

The local Node 22 runtime and `node_modules` were removed during cleanup. Current system Node may show warnings for newer Supabase packages.

---

# A. Critical — Complete i18n

## Client app
Hardcoded visible text still exists in:

```text
Pricing page
Login / Sign up page
Client dashboard
Projects / quotes page
Painting locked state
Painting legacy calculator
Lead page
Admin routes inside client app
Validation / alert messages
Placeholders
Empty states
Print labels
```

## Admin app
Hardcoded visible text still exists in:

```text
Auth gate
Header logout
Profile settings
Overview cards/panels
Security Center placeholder
Legacy AdminApp / Overview / Manage components
Some date/status/error fallback labels
```

## Required namespaces

```text
common.*
nav.*
auth.*
dashboard.*
profile.*
modules.*
subscriptions.*
security.*
peinture.*
print.*
validation.*
errors.*
actions.*
empty.*
status.*
accessibility.*
```

Requirements:

```text
FR / EN / AR
Arabic RTL
No visible hardcoded JSX text
No raw translation keys in production
Safe fallback when a translation is missing
Intl formatting for MAD, dates, and numbers
```

---

# B. Premium Peinture Workspace

## Component layer exists but is not live

```text
src/features/peinture/types.ts
src/features/peinture/engine.ts
src/features/peinture/number.ts
src/features/peinture/storage.ts
src/features/peinture/exporters.ts
src/features/peinture/CostBreakdownForm.tsx
src/features/peinture/PackageSelector.tsx
src/features/peinture/PricingStrategyPanel.tsx
src/features/peinture/QuotePreview.tsx
src/features/peinture/PeintureWorkspace.tsx
src/features/peinture/peinture.css
```

## Must complete before route wiring

```text
Add missing paint.* keys to all three languages
Wire PricingStrategyPanel into PeintureWorkspace
Add package comparison component
Add price floor / ceiling validation
Add profit target validation
Add VAT / discount validation
Add room type control
Add ceiling toggle
Add doors / trims toggle
Add interior / exterior selector
Add wall condition UI
Add regional preset UI
Add upsell suggestions UI
```

## Saved calculations library UI

```text
My Calculations screen
Save calculation
Open calculation
Rename calculation
Duplicate calculation
Delete calculation
Import JSON UI
Export JSON UI
Export CSV UI
Inline import errors
```

## Quote / invoice work

```text
Quote number editor
Validity date editor
Payment terms editor
Notes editor
Terms and conditions
Acceptance / signature area polish
Client/project metadata form
Professional invoice line-item detail
```

## Exports

```text
PDF export
Excel / XLSX export
CSV import mapping
Print-friendly HTML download
```

## Route wiring

Only after all previous items are complete:

```text
Replace Calculator() inside Painting() with PeintureWorkspace
Keep existing Peinture entitlement gate
Keep locked module UX
Keep old calculator as fallback until verified
```

---

# C. Modules / Subscriptions

## SQL migration

Confirm this migration was run:

```text
artisanpro-module-subscription-upgrade.sql
```

## Admin UI remaining work

```text
Proper user detail drawer/panel
Module access badges
Subscription state badges
Expiry editor for existing subscription rows
Manual payment history UI
Subscription amount input
Plan name selector
Access status timeline
Clear pending / expired / revoked states
Localized validation/errors
Localized confirmation dialogs
```

## Client side remaining work

```text
Show entitlement status / expiry in module card
Upgrade / contact admin CTA for locked module
Refresh entitlement after admin changes
Real subscription status screen
Real project/quote persistence in Supabase
```

---

# D. Security Center / Sessions

## SQL migration

Run:

```text
artisanpro-session-security-upgrade.sql
```

## Verify client session code

```text
Login claims session
Heartbeat updates last_seen_at
Logout ends session
New login invalidates old device
Forced logout signs old device out
```

## Missing Security Center

```text
Security Center tab in AdminPro
Real active sessions list
Online / offline status
Last seen
Session duration
Device / browser / OS
Force logout button
Session refresh
User session inspection
Empty/loading/error states
```

## Missing security logging

```text
Supabase Edge Function
Server-side hashed IP
login_success log
login_failed log
access_denied log
account_blocked log
logout log
forced_logout log
session_started log
session_expired log
90-day cleanup schedule
```

Never store:

```text
Raw IP
Password
Google token
service_role in browser
```

---

# E. AdminPro cleanup

Legacy/dead code remains in `artisanpro-admin/src/main.tsx`:

```text
AdminApp
Overview
Manage
labels dictionary
```

After i18n is stable:

```text
Remove unused legacy components
Remove duplicate dictionaries
Split AdminPro into reusable components
```

Recommended structure:

```text
artisanpro-admin/src/
├── i18n/
├── components/
│   ├── AdminShell.tsx
│   ├── UserDetailDrawer.tsx
│   ├── ModuleAccessPanel.tsx
│   ├── SubscriptionPanel.tsx
│   └── SecurityCenter.tsx
├── features/
│   ├── modules/
│   ├── subscriptions/
│   ├── security/
│   └── profile/
└── lib/
```

---

# F. Database / Supabase production work

## Client data migration

Current Client app still depends largely on:

```text
localStorage
mock data
```

Move to Supabase:

```text
clients
projects
quotes
paint calculations
saved quotes
module-specific settings
```

Requirements:

```text
Each client sees only their own data
Admin sees all data
RLS policies
No shared quote/project data
```

## Future Stripe integration

Strategy:

```text
Manual subscriptions now
Stripe later
```

Needed before Stripe:

```text
Manual payment record UI
Subscription amount history
Payment confirmation workflow
Expiry / renewal automation
Webhook architecture
```

---

# G. UI / RTL / Responsive audit

Check Arabic in:

```text
Client sidebar
Admin sidebar
Mobile navigation
Tables
Module panels
Subscription panels
Peinture workspace
Quote preview
Print layout
Icons and button spacing
Forms
Badges
Drawer alignment
```

Replace directional CSS with logical CSS:

```css
margin-inline-start
margin-inline-end
padding-inline-start
padding-inline-end
inset-inline-start
inset-inline-end
text-align: start
text-align: end
```

---

# H. Build / Deployment

Before each release:

```bash
cd /home/user
npm install
npm run build

cd /home/user/artisanpro-admin
npm install
npm run build
```

Verify Vercel variables in both projects:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
```

---

# Recommended priority order

```text
1. Full i18n cleanup
2. Finish Premium Peinture workspace
3. Wire Peinture workspace into protected route
4. Finish Modules / Subscriptions drawer and expiry UX
5. Build Security Center + Edge Function logging
6. Migrate client data from localStorage to Supabase
7. Manual payment workflow
8. Stripe
```
