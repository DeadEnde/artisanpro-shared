export type Role='client'|'admin'; export type ModuleSlug='peinture'|'carrelage';
export interface Module {slug:ModuleSlug; name:string; tagline:string; price:number; status:'active'|'coming'; icon:string; seoTitle:string; enabled:boolean}
export interface User {id:string; name:string; email:string; role:Role; company:string; modules:ModuleSlug[]; plan:string}
export interface Client {id:string; name:string; phone:string; city:string}
export interface Project {id:string; name:string; clientId:string; module:ModuleSlug; createdAt:string}
export interface Quote {id:string; number:string; projectId:string; clientName:string; title:string; area:number; liters:number; total:number; status:'draft'|'sent'; createdAt:string}
export interface AppData {users:User[]; modules:Module[]; clients:Client[]; projects:Project[]; quotes:Quote[]}
