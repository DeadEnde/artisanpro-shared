import {supabase} from './supabase';
import type {ModuleSlug} from '../types';

export type ModuleAccessStatus='active'|'paused'|'expired'|'revoked'|'pending'|'locked';
export type ModuleEntitlement={module_slug:ModuleSlug;status:ModuleAccessStatus;expires_at:string|null;is_unlocked:boolean};

export async function getUserModules(userId:string):Promise<ModuleEntitlement[]>{
  if(!supabase) return [];
  const {data,error}=await supabase.from('module_entitlements').select('module_slug,status,expires_at,is_unlocked').eq('user_id',userId);
  if(error) return [];
  return (data||[]) as ModuleEntitlement[];
}

export async function canAccessModule(userId:string,slug:ModuleSlug){
  const modules=await getUserModules(userId);
  return modules.some(module=>module.module_slug===slug&&module.is_unlocked);
}

export function isModuleLockedForUser(access:ModuleEntitlement|undefined){
  return !access?.is_unlocked;
}
