import {supabase} from './supabase';

const KEY='artisan-app-session-id';
const device=()=>({
  name:navigator.userAgent.slice(0,120),
  browser:/Chrome/i.test(navigator.userAgent)?'Chrome':/Safari/i.test(navigator.userAgent)?'Safari':'Browser',
  os:/Android/i.test(navigator.userAgent)?'Android':/iPhone|iPad/i.test(navigator.userAgent)?'iOS':/Windows/i.test(navigator.userAgent)?'Windows':'Unknown',
  type:/Mobi|Android|iPhone/i.test(navigator.userAgent)?'mobile':'desktop'
});
export async function claimAppSession(){
 if(!supabase)return null; const d=device();
 const {data,error}=await supabase.rpc('claim_single_session',{p_device_name:d.name});
 if(error)return null; localStorage.setItem(KEY,data); return data as string;
}
export const currentAppSession=()=>localStorage.getItem(KEY);
export async function heartbeat(){const id=currentAppSession();if(!supabase||!id)return false;const{data}=await supabase.rpc('heartbeat_session',{p_session_id:id});return !!data}
export async function endAppSession(){const id=currentAppSession();if(supabase&&id)await supabase.rpc('end_own_session',{p_session_id:id});localStorage.removeItem(KEY)}
