-- Run in Supabase > SQL Editor > New query
-- Adds editable business details to the existing profiles table.
alter table public.profiles
  add column if not exists company text,
  add column if not exists phone text,
  add column if not exists avatar_url text;
