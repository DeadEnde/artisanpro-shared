# Rapport d’avancement — ArtisanPro

_Date : 23 août 2026_

## 1. Client App — `artissan-pro.vercel.app`

### Disponible
- Home page, pricing, lead page et painting calculator.
- Login / Sign up design.
- Client dashboard et module Peinture.
- Calculateur de peinture et génération de devis MVP.
- Stockage MVP en `localStorage`.
- Sélecteur Français / English / العربية avec RTL partiel pour l’arabe.

### À terminer
- Migrer clients, projets et devis vers Supabase.
- Protéger le dashboard client avec les données de chaque utilisateur.
- Terminer toutes les traductions : des textes sont encore écrits directement dans certains composants.
- Brancher les accès réels par module et par abonnement.

---

## 2. Supabase — Foundation créée

Tables disponibles :

```text
profiles
modules
app_sessions
user_modules
subscriptions
admin_activity_logs
security_logs
```

### `profiles`
Chaque profil peut contenir :

```text
full_name
email
role
status
company
phone
avatar_url
```

### Rôles

```text
client
admin
```

Le Gmail de l’administrateur a été configuré avec le rôle `admin`.

### Fonctions SQL déjà préparées

```text
admin_set_user_status
admin_set_module_access
claim_single_session
is_session_active
```

---

## 3. AdminPro — `artisanpro-admin.vercel.app`

### Disponible
- Login Google via Supabase.
- Contrôle réel : seul `role = admin` et `status = active` peut entrer.
- Logout dans le header.
- Lecture des utilisateurs réels depuis `profiles`.
- Blocage / déblocage d’un utilisateur depuis la page Users.
- Dark / Light mode sauvegardé dans le navigateur.
- Langues : FR / EN / العربية.
- RTL pour l’arabe.
- Navigation mobile en bas de l’écran.
- Overview avec cards, revenue panel, activity panel et Security Center.
- Formulaire Mon profil : nom, entreprise, téléphone et email.

### État des données Overview

```text
Utilisateurs : réel
Comptes actifs : réel
Revenu mensuel : 0 tant qu’il n’y a pas de souscriptions réelles
Sessions en ligne : 0 tant que le tracking client n’est pas branché
Activité récente : empty state pour le moment
Security Center : interface prête, logs UI pas encore connectés
```

---

## 4. Traductions

### Fonctionnel
- Navigation principale.
- Cards principales de l’Overview.
- Dark mode et sélecteur de langue.
- Une grande partie de l’arabe et de l’anglais.

### À finaliser
La règle cible est :

```text
Aucun texte visible sans clé i18n.
```

Chaque texte doit être rendu via une clé comme :

```ts
{t('monthlyRevenue')}
```

avec une valeur en Français, English et العربية.

Il reste à auditer :
- Profile settings
- Security messages
- Modules
- Subscriptions
- Login / Sign up
- Client dashboard
- Empty states et messages d’erreur

---

## 5. Abonnements et permissions

### Foundation disponible

```text
modules
user_modules
subscriptions
```

### À construire dans l’interface Admin

```text
Grant Peinture
Revoke Peinture
Pause subscription
Resume subscription
Set expiry date
Manual payment history
```

Stratégie décidée :

```text
Manual subscription maintenant
Stripe plus tard
```

---

## 6. Single session et usage tracking

La table `app_sessions` est prête.

### À connecter dans Client App

```text
Login → claim_single_session
Activity → update last_seen_at
New device login → ancienne session arrêtée
Admin → Online/Offline, last seen, device, usage time, force logout
```

---

## 7. Security logs

Table `security_logs` prête pour stocker :

```text
login_success
login_failed
access_denied
account_blocked
logout
forced_logout
```

Données prévues :

```text
Client / Admin app
email
provider
browser
OS
device type
IP hash
reason
date/time
```

Rétention prévue : **90 jours**.

L’interface Security Center doit encore être branchée aux vraies données.

---

## 8. Prochain ordre recommandé

1. Audit i18n complet : FR / EN / AR sans textes hardcoded.
2. Task 7 : modules, subscriptions, pause/resume et grant/revoke.
3. Security Center réel : login logs, devices, online/offline.
4. Single-session system dans le Client App.
5. Migration Client App vers Supabase : clients, devis et projets.
6. Stripe après validation du flow manuel.
