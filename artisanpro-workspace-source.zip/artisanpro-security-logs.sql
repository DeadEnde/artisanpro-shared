-- ArtisanPro security audit logs (client + admin)
-- Run in Supabase SQL Editor after artisanpro-supabase-setup.sql

create table if not exists public.security_logs (
  id uuid primary key default gen_random_uuid(),
  occurred_at timestamptz not null default now(),
  app text not null check (app in ('client','admin')),
  event text not null check (event in ('login_success','login_failed','access_denied','account_blocked','logout','forced_logout')),
  email text,
  user_id uuid references public.profiles(id) on delete set null,
  provider text check (provider in ('google','email')),
  device_type text,
  browser text,
  os text,
  ip_hash text,
  reason text,
  metadata jsonb not null default '{}'::jsonb
);
create index if not exists security_logs_time_idx on public.security_logs(occurred_at desc);
create index if not exists security_logs_email_idx on public.security_logs(email);
create index if not exists security_logs_app_event_idx on public.security_logs(app,event);
alter table public.security_logs enable row level security;
create policy "admins read security logs" on public.security_logs for select using (public.is_admin());

-- Only secure backend/Edge Functions should insert logs. Browser clients must NOT insert directly.
create or replace function public.cleanup_security_logs()
returns void language sql security definer set search_path=public as $$
  delete from public.security_logs where occurred_at < now() - interval '90 days';
$$;

-- Run this manually once a month, or schedule it with Supabase Cron later:
-- select public.cleanup_security_logs();
