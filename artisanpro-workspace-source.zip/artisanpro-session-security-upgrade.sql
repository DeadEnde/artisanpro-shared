-- ArtisanPro session presence + force logout upgrade
alter table public.app_sessions
  add column if not exists browser text,
  add column if not exists os text,
  add column if not exists device_type text,
  add column if not exists user_agent text,
  add column if not exists status text not null default 'active';

alter table public.app_sessions drop constraint if exists app_sessions_status_check;
alter table public.app_sessions add constraint app_sessions_status_check
  check (status in ('active','expired','forced_logout','ended'));

create or replace function public.heartbeat_session(p_session_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  update app_sessions set last_seen_at=now()
  where id=p_session_id and user_id=auth.uid() and is_active=true and status='active';
  return found;
end; $$;

create or replace function public.end_own_session(p_session_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  update app_sessions set is_active=false,status='ended',ended_at=now()
  where id=p_session_id and user_id=auth.uid();
end; $$;

create or replace function public.admin_force_logout_session(p_session_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  update app_sessions set is_active=false,status='forced_logout',ended_at=now() where id=p_session_id;
  insert into admin_activity_logs(admin_id,action,metadata)
  values(auth.uid(),'force_logout_session',jsonb_build_object('session_id',p_session_id));
end; $$;

drop policy if exists "session owner heartbeat" on public.app_sessions;
create policy "session owner heartbeat" on public.app_sessions for update
using (user_id=auth.uid()) with check (user_id=auth.uid());
