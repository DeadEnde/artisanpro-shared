# ArtisanPro — AI Handoff Report

## Purpose
This file is a factual handoff for the next engineer/AI. The goal is to finish the SaaS safely, especially the full i18n cleanup and the real AdminPro functionality.

---

## Repository / Stack reality

> The requested/assumed stack was Next.js + next-intl, but this repository is currently **two Vite + React + TypeScript apps**, not Next.js.

```text
/home/user/                         Client app (Vite + React)
/home/user/artisanpro-admin/        Admin app (Vite + React)
```

Do **not** migrate frameworks as part of i18n. Preserve the current business/auth logic.

### Client app
- Deployed URL: `artissan-pro.vercel.app` (note the double `s` spelling in the current URL)
- Entrypoint: `src/main.tsx`
- State/data context: `src/context/AppContext.tsx`
- Existing i18n context: `src/context/LanguageContext.tsx`
- Supabase client: `src/lib/supabase.ts`
- Styling: `src/styles.css`

### Admin app
- Deployed URL: `artisanpro-admin.vercel.app`
- Entrypoint: `artisanpro-admin/src/main.tsx`
- Supabase client: `artisanpro-admin/src/supabase.ts`
- Styling: `artisanpro-admin/src/style.css`

---

## Important environment variables

Set in **both relevant Vercel projects**:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
```

Do not expose or use Supabase `service_role` in browser code.

---

## Supabase status

The user has already run the setup SQL successfully. Existing schema includes:

```text
profiles
modules
app_sessions
user_modules
subscriptions
admin_activity_logs
security_logs
```

Relevant source SQL files in the root:

```text
artisanpro-supabase-setup.sql
artisanpro-security-logs.sql
artisanpro-admin-profile-update.sql
```

### Existing roles/status

```text
role: client | admin
status: active | blocked | pending
```

The owner has set their Google account profile role to `admin`.

### Existing database functions

```text
public.is_admin()
public.admin_set_user_status(user_id, status)
public.admin_set_module_access(user_id, module_slug, status, expires_at)
public.claim_single_session(device_name)
public.is_session_active(session_id)
```

### Security
- Row Level Security was enabled by the setup SQL.
- Security log schema exists, but client/admin logging is **not yet implemented** through a secure backend/Edge Function.
- Do not collect passwords, Google tokens, or raw IPs. User chose **IP hash** and **90-day retention**.

---

## What works today

### Client app
- Public landing, painting calculator, pricing, lead page.
- Basic dashboard, quote calculator, mock/local persistence.
- Google OAuth foundation exists.
- Client app is still primarily a **localStorage MVP**; clients/projects/quotes are not fully migrated to per-user Supabase data.

### Admin app
- Google OAuth session check via Supabase.
- Access denied unless profile has:

```text
role = admin
status = active
```

- Logout.
- Reads real users from `profiles`.
- Block/Unblock control calls `admin_set_user_status`.
- Admin profile settings form saves `full_name`, `company`, `phone` into `profiles`.
- Dark/light mode is persisted as `admin-theme` in localStorage.
- Admin language is persisted as `admin-lang` in localStorage.
- Mobile navigation is implemented as a bottom navigation bar.

---

## Current AdminPro UI status

The latest local source has a real React `RealAdmin` component which displays:

```text
Overview
Users
Modules placeholder
Subscriptions placeholder
SEO content placeholder
Settings / profile form
```

Overview currently uses:

```text
Users count: real (`profiles`)
Active accounts: real (`profiles.status`)
Monthly revenue: 0 / no data
Online sessions: 0 / no data
Revenue chart: empty state
Activity: empty state
Security Center: empty state
```

This is intentional: user explicitly asked for **real data or zero**, never fake KPI data.

### Important admin source cleanup needed
`artisanpro-admin/src/main.tsx` still contains legacy/dead components near the top:

```text
AdminApp
Overview
Manage
```

The active app uses `App` + `RealAdmin`. Remove dead components once the refactor is stable to reduce confusion.

---

## Current i18n status

### Existing approach
- Client has `LanguageContext.tsx` using flat key dictionaries.
- Admin has a separate inline `UI` dictionary in `artisanpro-admin/src/main.tsx`.
- This is inconsistent and incomplete.

### Required final rule

```text
No user-visible text may be hardcoded in JSX/components.
Every visible string must use a translation key.
```

Use a consistent structure for both applications, ideally plain TypeScript dictionaries compatible with the existing Vite apps:

```text
common
nav
auth
dashboard
modules
subscriptions
security
forms
errors
pricing
profile
landing
seo
```

No framework migration is needed. A lightweight typed `useTranslation()` hook is sufficient.

### Languages

```text
fr — Français — dir=ltr
en — English — dir=ltr
ar — العربية الفصحى — dir=rtl
```

### Current problems
- Many static strings remain in client `src/main.tsx`, especially pricing, login/signup, dashboard, admin messages, errors, empty states, SEO text.
- Many static strings remain in admin `src/main.tsx`, especially profile form, auth gate, buttons, labels, errors and placeholders.
- Arabic RTL is partial. Use logical CSS properties (`margin-inline`, `padding-inline`, `text-align:start`) rather than direction-specific hacks where possible.
- Some screenshots showed French/Arabic mixed before the latest partial fixes.
- Screenshots later confirmed the Overview cards translate into English, but the complete app is not audited.

### Safe fallback
Translation calls must not crash when a key is missing. Return the key or a neutral fallback and log a dev warning.

---

## Mojibake / encoding

- Source files appear UTF-8 in the current workspace.
- The grep pattern may flag valid French accents such as `é`; do not blindly replace accented French.
- Search specifically for true mojibake artifacts:

```text
Ã©
Ã¨
â€™
â€œ
â€
Ø§
Ù„
�
```

- Ensure all `.ts`, `.tsx`, `.css`, `.json`, SQL, HTML files save as UTF-8.

---

## Current visual/design requirements

User approved a clean professional green construction SaaS design:

```text
Dark green sidebar
Light/dark mode
Four overview cards
Revenue/subscription panel
Activity panel
Security Center banner
Professional mobile bottom navigation
```

The user does not want fake users or fake revenue. Use real records or localized empty/zero states.

---

## Feature work still TODO

### Priority 1 — Full i18n audit
1. Scan both apps for all JSX/HTML literals, button text, labels, placeholders, `aria-label`, titles, errors, empty states, metadata.
2. Replace every visible string with keys.
3. Build three complete locale dictionaries.
4. Verify FR/EN/AR screen by screen.
5. Fix RTL using CSS logical properties.
6. Localize dates/numbers/currency via `Intl`:

```ts
new Intl.NumberFormat(locale, {style:'currency', currency:'MAD'})
new Intl.DateTimeFormat(locale, options)
```

### Priority 2 — Admin Task 7
Build real Modules / Subscriptions UI:

```text
Grant Peinture
Revoke Peinture
Pause subscription
Resume subscription
Set expiry date
Manual payment/subscription history
```

Use existing `modules`, `user_modules`, `subscriptions`, and `admin_set_module_access`.

### Priority 3 — Online/session tracking
Wire client app to `app_sessions`:

```text
on login → claim_single_session
periodic heartbeat → update last_seen_at
new login/device → previous session invalidated
admin → online/offline, last seen, device, force logout
```

Do not claim a user is online merely because an old auth session exists. Use a short heartbeat window, e.g. 2 minutes.

### Priority 4 — Security Center
- Record client/admin login success, failed/denied access, block, forced logout.
- Use a secure Supabase Edge Function/backend for inserts and hashed IP processing.
- Add admin-only filtering UI.
- Retain logs 90 days.

### Priority 5 — Client app real persistence
Migrate data from localStorage into Supabase with per-user RLS:

```text
clients
projects
quotes
module entitlements
```

Preserve client/admin role checks.

### Priority 6 — Payments
Manual subscription first. Stripe only after the manual subscription workflow is stable.

---

## Recent files / deliverables

Latest useful admin ZIP delivered to user was:

```text
artisanpro-admin-arabic-fix.zip
```

However, the current workspace source includes edits made after some old ZIP files. Before handing over a new build, create one clean, clearly named package only, e.g.:

```text
artisanpro-admin-v1-i18n-complete.zip
```

Run before delivery:

```bash
cd /home/user && npm run build
cd /home/user/artisanpro-admin && npm run build
```

---

## User communication preference

The user works from an Android phone and deploys via GitHub + Vercel. Explain steps in Moroccan Darija, short and practical. Do not repeatedly promise work without an actual ZIP/build. Be explicit whether a change is implemented, pending, or only a design preview.
