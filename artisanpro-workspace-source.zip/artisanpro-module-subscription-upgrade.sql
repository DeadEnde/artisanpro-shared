-- ArtisanPro module/subscription access upgrade
-- Run once in Supabase SQL Editor after the initial schema.

alter table public.user_modules drop constraint if exists user_modules_status_check;
alter table public.user_modules add constraint user_modules_status_check
  check (status in ('active','paused','expired','revoked','pending'));

alter table public.subscriptions drop constraint if exists subscriptions_status_check;
alter table public.subscriptions add constraint subscriptions_status_check
  check (status in ('pending','active','paused','cancelled','expired'));

-- Securely create/update the manual subscription record used by AdminPro.
create or replace function public.admin_set_subscription_status(
  p_user_id uuid,
  p_plan_name text,
  p_status text,
  p_expires_at timestamptz default null,
  p_amount numeric default 0
)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  if p_status not in ('pending','active','paused','cancelled','expired') then
    raise exception 'Invalid subscription status';
  end if;

  insert into public.subscriptions(user_id,plan_name,amount,status,payment_source,expires_at,created_by)
  values(p_user_id,p_plan_name,coalesce(p_amount,0),p_status,'manual',p_expires_at,auth.uid());

  insert into public.admin_activity_logs(admin_id,action,target_user_id,metadata)
  values(auth.uid(),'set_subscription_status',p_user_id,
    jsonb_build_object('plan',p_plan_name,'status',p_status,'expires_at',p_expires_at,'amount',p_amount));
end;
$$;

-- Read-only entitlement view. Clients can see only rows allowed by existing RLS.
create or replace view public.module_entitlements with (security_invoker = true) as
select um.user_id, m.slug as module_slug, um.status, um.starts_at, um.expires_at,
  case
    when um.status <> 'active' then false
    when um.expires_at is not null and um.expires_at <= now() then false
    else true
  end as is_unlocked
from public.user_modules um
join public.modules m on m.id=um.module_id;
