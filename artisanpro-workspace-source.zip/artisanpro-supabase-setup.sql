-- ArtisanPro: production access-control foundation
-- Run this entire file in Supabase > SQL Editor > New query.
-- It creates profiles, one-device sessions, module access, manual subscriptions and admin audit logs.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'Nouveau client',
  email text unique,
  role text not null default 'client' check (role in ('client','admin')),
  status text not null default 'active' check (status in ('active','blocked','pending')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.modules (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name_fr text not null,
  name_en text not null,
  name_ar text not null,
  monthly_price numeric(10,2) not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.modules (slug,name_fr,name_en,name_ar,monthly_price,is_published)
values ('peinture','Peinture','Painting','الصباغة',99,true),
       ('carrelage','Carrelage','Tiling','التبليط',119,false)
on conflict (slug) do nothing;

create table if not exists public.app_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  device_name text not null default 'Unknown device',
  is_active boolean not null default true,
  started_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  ended_at timestamptz
);
create unique index if not exists one_active_session_per_user on public.app_sessions(user_id) where is_active=true;

create table if not exists public.user_modules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  module_id uuid not null references public.modules(id) on delete cascade,
  status text not null default 'active' check (status in ('active','revoked','expired')),
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  source text not null default 'manual' check (source in ('manual','stripe','admin_grant')),
  granted_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique(user_id,module_id)
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_name text not null,
  amount numeric(10,2) not null default 0,
  currency text not null default 'MAD',
  status text not null default 'active' check (status in ('pending','active','cancelled','expired')),
  payment_source text not null default 'manual' check (payment_source in ('manual','stripe')),
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.admin_activity_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles(id),
  action text not null,
  target_user_id uuid references public.profiles(id),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Each Auth user automatically receives a client profile.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles (id,full_name,email)
  values (new.id,coalesce(new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'name','Nouveau client'),new.email)
  on conflict (id) do update set email=excluded.email;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Populate profiles for users created before this script.
insert into public.profiles (id,full_name,email)
select id,coalesce(raw_user_meta_data->>'full_name',raw_user_meta_data->>'name','Nouveau client'),email from auth.users
on conflict (id) do update set email=excluded.email;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and status='active');
$$;

-- One active application session. A new device invalidates the previous device.
create or replace function public.claim_single_session(p_device_name text default 'Unknown device')
returns uuid language plpgsql security definer set search_path=public as $$
declare new_session uuid;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  if not exists(select 1 from profiles where id=auth.uid() and status='active') then raise exception 'Account is blocked or pending'; end if;
  update app_sessions set is_active=false,ended_at=now() where user_id=auth.uid() and is_active=true;
  insert into app_sessions(user_id,device_name) values(auth.uid(),left(coalesce(p_device_name,'Unknown device'),120)) returning id into new_session;
  return new_session;
end; $$;
create or replace function public.is_session_active(p_session_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  return exists(select 1 from app_sessions where id=p_session_id and user_id=auth.uid() and is_active=true);
end;
$$;

-- Admin actions: call only from the separate admin app while logged in as an admin.
create or replace function public.admin_set_user_status(p_user_id uuid,p_status text)
returns void language plpgsql security definer set search_path=public as $$
begin
 if not is_admin() then raise exception 'Admin permission required'; end if;
 if p_status not in ('active','blocked','pending') then raise exception 'Invalid status'; end if;
 update profiles set status=p_status,updated_at=now() where id=p_user_id;
 if p_status='blocked' then update app_sessions set is_active=false,ended_at=now() where user_id=p_user_id and is_active=true; end if;
 insert into admin_activity_logs(admin_id,action,target_user_id,metadata) values(auth.uid(),'set_user_status',p_user_id,jsonb_build_object('status',p_status));
end; $$;
create or replace function public.admin_set_module_access(p_user_id uuid,p_module_slug text,p_status text,p_expires_at timestamptz default null)
returns void language plpgsql security definer set search_path=public as $$
declare mod_id uuid;
begin
 if not is_admin() then raise exception 'Admin permission required'; end if;
 select id into mod_id from modules where slug=p_module_slug;
 if mod_id is null then raise exception 'Module not found'; end if;
 insert into user_modules(user_id,module_id,status,expires_at,source,granted_by)
 values(p_user_id,mod_id,p_status,p_expires_at,'manual',auth.uid())
 on conflict(user_id,module_id) do update set status=excluded.status,expires_at=excluded.expires_at,granted_by=auth.uid();
 insert into admin_activity_logs(admin_id,action,target_user_id,metadata) values(auth.uid(),'set_module_access',p_user_id,jsonb_build_object('module',p_module_slug,'status',p_status,'expires_at',p_expires_at));
end; $$;

alter table public.profiles enable row level security;
alter table public.modules enable row level security;
alter table public.app_sessions enable row level security;
alter table public.user_modules enable row level security;
alter table public.subscriptions enable row level security;
alter table public.admin_activity_logs enable row level security;

create policy "profile self or admin read" on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy "modules public read" on public.modules for select using (true);
create policy "session self or admin read" on public.app_sessions for select using (user_id=auth.uid() or public.is_admin());
create policy "module access self or admin read" on public.user_modules for select using (user_id=auth.uid() or public.is_admin());
create policy "subscriptions self or admin read" on public.subscriptions for select using (user_id=auth.uid() or public.is_admin());
create policy "logs admin only" on public.admin_activity_logs for select using (public.is_admin());

-- AFTER YOUR FIRST GOOGLE LOGIN, replace the email below then run this one statement.
-- update public.profiles set role='admin' where email='YOUR_ADMIN_EMAIL@gmail.com';
